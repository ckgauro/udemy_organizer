package com.gauro.udemyorganizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdemyorganizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdemyorganizerApplication.class, args);
	}

}
