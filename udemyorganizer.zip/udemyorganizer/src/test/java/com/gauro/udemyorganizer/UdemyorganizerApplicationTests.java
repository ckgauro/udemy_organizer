package com.gauro.udemyorganizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UdemyorganizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
